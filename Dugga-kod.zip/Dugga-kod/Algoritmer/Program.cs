﻿using System;
using System.Collections.Generic;

namespace Algoritmer
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] unsortedArray = { 4, 2, 7, 8, 9, 10, 1, 3 };

            //InsertSort
            // Console.WriteLine("Insert Sort: ");
            // Console.WriteLine("Initial array: " );
            // PrintArray(unsortedArray);
            // Console.WriteLine("\nSorted array: ");
            // InsertionSort(unsortedArray);


            //SelectionSort
            // Console.WriteLine("\nSelection Sort: ");
            // Console.WriteLine("Initial array: " );
            // PrintArray(unsortedArray);
            // Console.WriteLine("\nSorted array: " );
            // SelectionSort(unsortedArray);


            //BubbleSort
            // Console.WriteLine("Bubble Sort: ");
            // Console.WriteLine("Initial Array: ");
            // PrintArray(unsortedArray); 
            // Console.WriteLine("\nSorted: ");
            // BubbleSort(unsortedArray);

            //Heap

            // int[] arr = { 12, 11, 13, 5, 6, 7 };
            // int n = unsortedArray.Length;
            // HeapSort obj = new HeapSort();
            // obj.sort(arr);

            //CountingSort
            // int[] arr = {0, 2, 3, 4, 7, 2, 3, 8, 4, 8, 2, 3, 4, 0, 0, 5, 2, 1, 8, 2, 1, 9, 3, 3, 3, 3,};
            // int range = 10;
            // int[] resultArray = CountingSort(arr, range);
            // Console.WriteLine("Sorted array: \n");
            // PrintIntArray(resultArray);

            int[] myArray = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
            int target = 6;

            //Linear Search
            // Console.WriteLine("The Array: ");
            // PrintIntArray(myArray);
            // Console.WriteLine("\nTarget: ");
            // Console.WriteLine(LinearSearch(myArray, target));

            //Binary Search
            // int target = 6;
            // Console.WriteLine(BinarySearch(myArray, target));

            //Binary Search Recursive
            // int[] arr = { 2, 3, 4, 10, 40 };
            // int n = arr.Length;
            // int x = 10;
    
            // int result = binarySearchRecursive(arr, 0, n - 1, x);
    
            // if (result == -1)
            //     Console.WriteLine("Element not present");
            // else
            //     Console.WriteLine("Element found at index "
            //                     + result);

            //InterPolation Search
            //Console.WriteLine(InterPolation(myArray, target));

            //Majority Voting / BoyerMooreVote
            // List<string> MyStringList = new List<string>(new string[]{"this", "is","a","boyer", "moore", "moore", "moore", "moore", "moore", "moore", "test"});
            // Console.WriteLine(BoyerMooreVoting(MyStringList));

            //Recirsive Factorial Algorithem
            // int n = 4; //Max n = 19 överskrider hur stor en int får vara.
            // Console.WriteLine(FactorialRecursive(n));

            //Fibonacci Recursive
            // int n = 31;
            // Console.WriteLine(FibonacciRecursive(n));

            //Tower of Hanoi
            // int n = 3;
            // char from_peg = 'A';
            // char to_peg = 'C';
            // char other_peg = 'B';
            // TowerOfHanoi(n, from_peg, to_peg, other_peg);

            //NonRecursive Factoral Algorithem
            // int n = 4; //// max n = 19
            // FactorialNonRecursive(n);

            //Dynamic programming Fibonacci numbers
            // int n = 9; ////Can calculate n = 92 since larger then 92 is gonna exceed the fit for a integer
            // Console.WriteLine(DynamicFibonacci(n));
           
        }

        private static int DynamicFibonacci(int n)
        {
            int[] FibValues = new int[100];

            FibValues[0] = 0;
            FibValues[1] = 1;
            int MaxN = 1;

            if(MaxN < n)
            {
                FibValues[n] = DynamicFibonacci(n-1) + DynamicFibonacci(n-2);
                MaxN = n;
            }
            return FibValues[n];
        }

        private static int DynamicFibonacciForLoop(int n)
        {
            int[] f = new int[n + 2];
            f[0] = 0;
            f[1] = 1;

            for (int i = 2; i <= n; i++)
            {
                f[i] = f[i - 1] + f[i -2];
            }
            return f[n];
        }

        private static void FactorialNonRecursive(int n)
        {
            int res = 1;
            while(n != 0)
            {
                res = res * n;
                n = n - 1;
            }
            Console.WriteLine("Result: " + res);
        }

        private static void TowerOfHanoi(int n, char from_peg, char to_peg, char other_peg)
        {
            if(n == 1)
            {
                Console.WriteLine("Disk 1 " + from_peg + " --> " + to_peg);
                return;
            }
            TowerOfHanoi(n-1, from_peg, other_peg, to_peg);
            Console.WriteLine("Disk " + n + " " + from_peg + " --> " + to_peg);
            TowerOfHanoi(n-1, other_peg, to_peg, from_peg);
        }

        private static int FibonacciRecursive(int n)
        {
            if(n <= 1)
            {
                return n;
            }
            return FibonacciRecursive(n - 1) + FibonacciRecursive(n - 2);
        }

        private static int FactorialRecursive(int n)
        {
            if(n > 1)
            {
                return FactorialRecursive(n - 1) * n;
            }
            else
            {
                return 1;
            }
        }

        private static string BoyerMooreVoting(List<string> myStringList)
        {
            string Majority = "";
            int count = 0;

            foreach (string element in myStringList)
            {
                if (count == 0)
                {
                    Majority = element;
                    count = 1;
                }
                else if(element == Majority)
                {
                    count++;
                }
                else
                {
                    count--;
                }
            }
            return "Majority string: " + Majority;
        }

        private static string InterPolation(int[] myArray, int target)
        {
            int min = 0;
            int max = myArray.Length - 1;
            int mid;
            while (min <= max)
            {
                mid = min + (max - min) * (target - myArray[min]) / (myArray[max] - myArray[min]);

                if (myArray[mid] == target)
                {
                    return "Target at index: " + mid;
                }
            }
            return "Target not in array!";
        }

        private static int binarySearchRecursive(int[] arr, int l, int r, int x)
        {
            if (r >= l) {
            int mid = l + (r - l) / 2;
 
            // If the element is present at the
            // middle itself
            if (arr[mid] == x)
                return mid;
 
            // If element is smaller than mid, then
            // it can only be present in left subarray
            if (arr[mid] > x)
                return binarySearchRecursive(arr, l, mid - 1, x);
 
            // Else the element can only be present
            // in right subarray
            return binarySearchRecursive(arr, mid + 1, r, x);
        }
 
        // We reach here when element is not present
        // in array
        return -1;
        }

        private static string BinarySearch(int[] myArray, int target)
        {
           int min = 0;
           int max = myArray.Length - 1;
           int mid; 
           while (min <= max)
           {
               mid = (min + max) / 2;
               if (target < myArray[mid])
               {
                   max = mid - 1;
               }
               else if(target > myArray[mid])
               {
                   min = mid + 1;
               }
               else
               {
                   return "Target: " + mid;
               }
           } 
           return "Target was not in array";
        }

        private static string LinearSearch(int[] myArray, int target)
        {
            for(int i = 0; i < myArray.Length - 1; i++)
            {
                if(myArray[i] == target)
                {
                    return "Target is at: "+ i;
                }
                if(myArray[i] > target)
                {
                    return "Target is not in the Array";
                }
            }
            return "Target is not in the Array";
        }

        private static void PrintIntArray(int[] arr)
        {
            for(int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
        }

        private static int[] CountingSort(int[] arr, int range)
        {
            int[] CountArray = new int[range];

            for(int i = 0; i < arr.Length; i++)
            {
                CountArray[arr[i]]++;
            }

            for(int i = 1; i < range; i++)
            {
                CountArray[i] = CountArray[i] + CountArray[i - 1];
            }

            int[] resultArray = new int[arr.Length];

            for(int i = arr.Length - 1; i >= 0; i--)
            {
                resultArray[CountArray[arr[i]] - 1] = arr[i];

                CountArray[arr[i]] = CountArray[arr[i]] - 1;
            }
            return resultArray;
        }

        private static void BubbleSort(double[] unsortedArray)
        {
            double temp;

            for (int i = 0; i < unsortedArray.Length - 1; i++)
            {
                for (int j = 0; j < unsortedArray.Length - (1 + i); j++)
                {
                    if (unsortedArray[j] > unsortedArray[j + 1])
                    {
                        temp = unsortedArray[j + 1];
                        unsortedArray[j + 1] = unsortedArray[j];
                        unsortedArray[j] = temp;
                    }
                }
            }
            PrintArray(unsortedArray);
        }

        private static void SelectionSort(double[] unsortedArray)
        {
            int MinIndex = 0; // Current index of the current minimum we are looking for
            double MinValueFound = 0; // temp variable for swaping the value of MinIndex

            //Börja loopa från början till slutet av arrayen
            for (int index = 0; index < unsortedArray.Length; index++)
            {
                MinIndex = index;

                //Loopar igenom och kollar om värdet vi står på är mindre än Minindex och om det är det byter vi värdena med varandra och fortsätter loopa.
                for (int RemainingIndex = MinIndex + 1; RemainingIndex < unsortedArray.Length; RemainingIndex++)
                {
                    if (unsortedArray[RemainingIndex] < unsortedArray[MinIndex])
                    {
                        MinIndex = RemainingIndex;
                    }
                }

                //Här sätter vi in vårat MinIndex som vi hittat så att om 10 ligger på plats 0 och 1 på plats 3 i arrayen kommer de bytas 
                //Vi fortsätter sedan loopa igenom arrayen från nästa värde så att vi stegrar uppåt (börja leta efter minsta och sedan näst minsta osv..)
                MinValueFound = unsortedArray[MinIndex];
                unsortedArray[MinIndex] = unsortedArray[index];
                unsortedArray[index] = MinValueFound;

            }
            PrintArray(unsortedArray);
        }

        private static void PrintArray(double[] unsortedArray)
        {
            for (int i = 0; i < unsortedArray.Length; i++)
            {
                Console.Write(unsortedArray[i] + " ");
            }
        }


        private static void InsertionSort(double[] unsortedArray)
        {
            int i = 1;
            int j = i;
            double temp = 0;
            while (i < unsortedArray.Length)
            {
                j = i;

                while (j > 0 && unsortedArray[j - 1] > unsortedArray[j])
                {
                    temp = unsortedArray[j];
                    unsortedArray[j] = unsortedArray[j - 1];
                    unsortedArray[j - 1] = temp;
                    j--;
                }
                i++;
            }
            PrintArray(unsortedArray);
        }
    }

}

        public class HeapSort
        {
            public void sort(int[] arr)
            {
                int n = arr.Length;

                // Build heap (rearrange array)
                for (int i = n / 2 - 1; i >= 0; i--)
                    heapify(arr, n, i);

                // One by one extract an element from heap
                for (int i = n - 1; i > 0; i--)
                {
                    // Move current root to end
                    int temp = arr[0];
                    arr[0] = arr[i];
                    arr[i] = temp;

                    // call max heapify on the reduced heap
                    heapify(arr, i, 0);
                    printArray(arr);
                }
            }

            // To heapify a subtree rooted with node i which is
            // an index in arr[]. n is size of heap
            void heapify(int[] arr, int n, int i)
            {
                int largest = i; // Initialize largest as root
                int l = 2 * i + 1; // left = 2*i + 1
                int r = 2 * i + 2; // right = 2*i + 2

                // If left child is larger than root
                if (l < n && arr[l] > arr[largest])
                    largest = l;

                // If right child is larger than largest so far
                if (r < n && arr[r] > arr[largest])
                    largest = r;

                // If largest is not root
                if (largest != i)
                {
                    int swap = arr[i];
                    arr[i] = arr[largest];
                    arr[largest] = swap;

                    // Recursively heapify the affected sub-tree
                    heapify(arr, n, largest);
                }
            }

            /* A utility function to print array of size n */
            static void printArray(int[] arr)
            {
                int n = arr.Length;
                for (int i = 0; i < n; ++i)
                    Console.Write(arr[i] + " ");
                Console.Read();
            }

        }