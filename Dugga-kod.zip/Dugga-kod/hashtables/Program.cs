﻿using System;
using System.Collections;

namespace hashtables
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable hash = new Hashtable();
            hash.Add(1, "1");
            hash.Add(2, "2");
            hash.Add(3, "3");
            hash.Add(4, "4");

            ICollection key = hash.Keys;

            //Print Hash table
            Console.WriteLine("Hashtable: ");
            Console.WriteLine();
            foreach (var item in key)
            {
                Console.WriteLine(item + "-" + hash[item]);
            }
        }
    }

    public class cell
    {
        public int key;
        public string value;
        public Cell next;

        public cell(int key, string value, cell next)
        {
            int Key = key;
            string Value = value;
            cell Next = next;
        }
    }
}
