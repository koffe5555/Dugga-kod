﻿using System;
using LinkedLists;

namespace LinkedLists
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkedList myList = new LinkedList();
            myList.Push(5);
            myList.Push(4);
            myList.Push(3);
            myList.Push(2);
            myList.Push(1);

            myList.PrintList();

            int target = 3;
            Console.WriteLine(myList.LinearSearch(target));


        }
    }

    public class Node{
        public int data;
        public Node next;
        
    }
    public class LinkedList
    {
        private Node top;

        public string LinearSearch(int target)
        {
            Node current = top;
            while(current != null)
            {
                if(current.data == target)
                {
                    return "Target is at: " + current.data;
                }
                current = current.next;
            }
            return "Target is not in linked List!";
        }

        internal void PrintList()
        {
            Node current = top;
            while(current != null){
                Console.WriteLine(current.data);
                current = current.next;
            }
        }

        internal void Push(int data)
        {
            Node NewNode = new Node();
            NewNode.data = data;
            NewNode.next = top;
            top = NewNode;
        }
    }


}
